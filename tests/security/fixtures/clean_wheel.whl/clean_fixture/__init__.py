"""Test fixture: empty placeholder package."""
