# malicious fixture stub
